import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Map, MessageCircle, MousePointer2 } from 'lucide-react';
import type { ScenarioStep, LegalConcept } from '@/types';
import { ExploreInteraction } from './interactions/ExploreInteraction';
import { DialogueInteraction } from './interactions/DialogueInteraction';
import { DecisionInteraction } from './interactions/DecisionInteraction';
import { DocumentInteraction } from './interactions/DocumentInteraction';
import { SortingInteraction } from './interactions/SortingInteraction';
import { TimelineInteraction } from './interactions/TimelineInteraction';

interface SceneViewProps { scene: ScenarioStep; concepts: LegalConcept[]; onConceptDiscovered: (conceptId: string) => void; discoveredConceptIds: string[]; }

export function SceneView({ scene, concepts, onConceptDiscovered, discoveredConceptIds }: SceneViewProps) {
  const [showNarration, setShowNarration] = useState(true);
  const interactionProps = { concepts, onConceptDiscovered, discoveredConceptIds };
  const interaction = (() => {
    switch (scene.interaction.type) {
      case 'explore': return <ExploreInteraction data={scene.interaction.data} {...interactionProps} />;
      case 'dialogue': return <DialogueInteraction data={scene.interaction.data} {...interactionProps} />;
      case 'decision': return <DecisionInteraction data={scene.interaction.data} {...interactionProps} />;
      case 'document': return <DocumentInteraction data={scene.interaction.data} {...interactionProps} />;
      case 'sorting': return <SortingInteraction data={scene.interaction.data} {...interactionProps} />;
      case 'timeline': return <TimelineInteraction data={scene.interaction.data} {...interactionProps} />;
    }
  })();
  const labels: Record<string,string> = { explore:'Explore', dialogue:'Dialogue', decision:'Decision', document:'Inspect', sorting:'Organise', timeline:'Reconstruct' };

  return (
    <div className="space-y-4">
      <div className="card-base overflow-hidden">
        <div className="p-4 sm:p-5 flex items-start justify-between gap-4 bg-white">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal">
              <Map size={14} /> Scene {labels[scene.interaction.type]}
            </div>
            <h2 className="mt-1 text-xl font-bold text-navy">{scene.title}</h2>
          </div>
          <button className="btn-ghost text-xs shrink-0" onClick={() => setShowNarration(v => !v)} aria-expanded={showNarration}>
            <MessageCircle size={14} /> {showNarration ? 'Hide story' : 'Show story'}
          </button>
        </div>
        {showNarration && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="px-4 pb-4 sm:px-5 sm:pb-5">
            <div className="p-4 rounded-lg bg-navy/[0.03] text-ink-light leading-relaxed">{scene.narration}</div>
          </motion.div>
        )}
      </div>
      <div className="flex items-center gap-2 text-xs text-ink-muted px-1"><MousePointer2 size={13} /> Explore the highlighted elements and use the controls to continue.</div>
      {interaction}
    </div>
  );
}
