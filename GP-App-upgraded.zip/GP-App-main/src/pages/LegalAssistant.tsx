import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, ArrowRight, BookOpen, ChevronRight, ExternalLink, HelpCircle, LifeBuoy, Loader2, Send, ShieldAlert } from 'lucide-react';
import { Card, TrustBadge } from '@/components/Card';
import { Disclaimer } from '@/components/Disclaimer';
import { legalDomains, getDomainByKeyword } from '@/data/legalDomains';
import { getSourcesByDomain } from '@/data/sources';
import { getScenarioById } from '@/data/scenarios';
import type { AIResponse, LegalDomain } from '@/types';

const DISCLAIMER = 'This tool provides general legal information for educational purposes. It is not a substitute for advice from a qualified legal professional. Laws and procedures can change, and the appropriate option depends on the circumstances.';

type State = 'idle'|'loading'|'success'|'empty'|'unclear';

const examples = [
  'My insurance company rejected my claim and I do not understand why.',
  'My landlord has not returned my security deposit after I moved out.',
  'I bought a product online and the seller will not refund me.',
  'I received a legal notice and I am not sure what it means.',
];

function makeResponse(input: string, domainId: LegalDomain): AIResponse {
  const domain = legalDomains.find(d => d.id === domainId)!;
  const scenario = domain.relatedScenarioId ? getScenarioById(domain.relatedScenarioId) : undefined;
  const sourceItems = getSourcesByDomain(domainId).filter(s => s.isOfficial).slice(0, 3);
  const checksByDomain: Record<string, { item:string; explanation:string }[]> = {
    insurance: [{ item:'Policy wording', explanation:'Check the cover, exclusions, conditions and the reason given for the decision.' }, { item:'Claim records', explanation:'Keep the claim, supporting documents and the insurer’s written response.' }, { item:'Grievance information', explanation:'Look for the insurer’s official grievance route and current regulator guidance.' }],
    'property-land': [{ item:'Property documents', explanation:'Identify the relevant title-related and property records for the transaction.' }, { item:'Agreement', explanation:'Review the terms, parties and obligations in the proposed transaction.' }, { item:'Professional due diligence', explanation:'For a real transaction, consider qualified property/legal review before committing.' }],
    consumer: [{ item:'Receipt or invoice', explanation:'Keep proof of purchase and payment.' }, { item:'Product or service records', explanation:'Keep photos, warranty information and relevant records.' }, { item:'Communication', explanation:'Keep written communication with the seller or service provider.' }],
    housing: [{ item:'Rental agreement', explanation:'Review deposit, handover and other relevant terms.' }, { item:'Handover records', explanation:'Keep photos, inspection notes and proof of key return where relevant.' }, { item:'Communication', explanation:'Keep written communication about rent, deposit or deductions.' }],
    employment: [{ item:'Employment agreement', explanation:'Review the terms relevant to the issue.' }, { item:'Payslips or payment records', explanation:'Keep records that show what was paid or remains outstanding.' }, { item:'Workplace communications', explanation:'Preserve relevant written communications.' }],
    digital: [{ item:'Digital records', explanation:'Preserve screenshots, messages, transaction references and other relevant records.' }, { item:'Account security', explanation:'Use the affected service’s official security and reporting tools.' }],
    'money-banking': [{ item:'Transaction details', explanation:'Keep the date, amount, reference number and relevant bank communication.' }, { item:'Complaint reference', explanation:'Keep the reference number from the bank’s complaint process.' }],
    courts: [{ item:'Notice or court document', explanation:'Identify the parties, dates, subject and any response information.' }, { item:'Case details', explanation:'Keep official case or filing references where available.' }],
    'legal-help': [{ item:'Your core question', explanation:'Write down the issue and what outcome or information you are trying to understand.' }, { item:'Relevant documents', explanation:'Organise the documents a qualified professional may need to review.' }],
  };
  const generic = [{ item:'Documents and dates', explanation:'Keep relevant agreements, receipts, notices, dates and written communications.' }, { item:'Official records', explanation:'Prefer records and instructions from the relevant authority or service provider.' }];
  const next = domainId === 'legal-help' ? [{ number:'01', title:'Explore legal aid', explanation:'Check whether you may be eligible for legal aid through the Legal Services Authorities.' }, { number:'02', title:'Organise the issue', explanation:'Prepare a short factual summary and relevant documents for professional help if needed.' }] : [{ number:'01', title:'Understand the written information', explanation:'Review the documents, dates and communications connected to the issue.' }, { number:'02', title:'Check an official source', explanation:'Use a verified source relevant to the legal area rather than relying on an unverified post or message.' }, { number:'03', title:'Consider appropriate help', explanation:'If the matter is important, urgent or disputed, consider qualified professional assistance.' }];
  return { situationSummary:`From what you described, this may involve ${domain.label.toLowerCase()}.`, possibleAreas:[domain.label], whatThisMayInvolve: `${domain.description} The exact legal position could depend on the facts, documents, dates and applicable law.`, whatToCheck: checksByDomain[domainId] || generic, possibleNextSteps: next, officialSources: sourceItems.map(s=>({title:s.title,organization:s.organization,url:s.url})), questionsToConsider:['What documents or records do you already have?','What dates, deadlines or written responses are involved?','Is there an official authority or service provider process you have not checked yet?'], disclaimer: DISCLAIMER, relatedScenarioId: scenario?.id, relatedDomain: domainId };
}

export function LegalAssistant() {
  const [input,setInput] = useState('');
  const [state,setState] = useState<State>('idle');
  const [response,setResponse] = useState<AIResponse|null>(null);
  const [selectedDomain,setSelectedDomain] = useState<LegalDomain|null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(()=>{ if(response) ref.current?.scrollIntoView({behavior:'smooth',block:'start'}); },[response]);

  const submit = (forcedDomain?: LegalDomain) => {
    const text=input.trim();
    if(!text){ setState('empty'); return; }
    setState('loading'); setResponse(null);
    window.setTimeout(()=>{
      const domain = forcedDomain || getDomainByKeyword(text)?.id;
      if(!domain){ setSelectedDomain(null); setState('unclear'); return; }
      setResponse(makeResponse(text, domain)); setSelectedDomain(domain); setState('success');
    },650);
  };

  return <div className="py-10"><div className="container-page max-w-4xl">
    <div className="text-center mb-8"><div className="w-14 h-14 rounded-xl bg-navy/8 flex items-center justify-center text-navy mx-auto mb-4"><LifeBuoy size={28}/></div><p className="section-label">I have a legal problem</p><h1 className="mt-2 text-3xl sm:text-4xl font-bold text-navy">Describe your situation</h1><p className="mt-3 text-ink-light text-lg">Tell us what happened in your own words. You don’t need to know the legal terminology.</p></div>
    <Card className="p-5 sm:p-6 mb-6">
      <textarea value={input} onChange={e=>setInput(e.target.value)} placeholder="For example: My insurance company rejected my claim and I don't understand why..." rows={6} className="input-base resize-none text-base" aria-label="Describe your legal situation" />
      <div className="mt-3 flex items-start gap-2.5 p-3.5 bg-navy/[0.03] rounded-lg"><ShieldAlert size={16} className="text-gold-600 shrink-0 mt-0.5"/><p className="text-xs text-ink-light leading-relaxed">Please don’t include passwords, financial credentials, government ID numbers, full addresses, phone numbers or other highly sensitive personal information.</p></div>
      <div className="mt-5"><p className="text-sm font-medium text-navy mb-2">Not sure where to start?</p><div className="flex flex-wrap gap-2">{legalDomains.filter(d=>['police-crime','property-land','insurance','employment','consumer','housing','courts','digital','legal-help','other'].includes(d.id)).map(d=><button key={d.id} onClick={()=>{setSelectedDomain(d.id); if(d.id!=='other') submit(d.id)}} className={`chip hover:chip-active ${selectedDomain===d.id?'chip-active':''}`}>{d.shortLabel}</button>)}</div></div>
      <button onClick={()=>submit()} disabled={state==='loading'} className="btn-primary w-full mt-5">{state==='loading'?<><Loader2 size={18} className="animate-spin"/>Understanding your situation…</>:<><Send size={18}/>Understand my situation</>}</button>
    </Card>

    {state==='idle' && <div className="mb-8"><p className="text-sm text-ink-light mb-3">Try an example:</p><div className="grid sm:grid-cols-2 gap-2">{examples.map(e=><button key={e} onClick={()=>setInput(e)} className="text-left p-3.5 bg-white border border-navy/8 rounded-lg text-sm text-ink-light hover:border-teal hover:text-navy transition-colors">{e}</button>)}</div></div>}
    {state==='empty' && <Card className="p-5 text-center border-warning/30"><HelpCircle className="text-warning mx-auto mb-2"/><p className="text-ink-light">Please describe what happened before continuing.</p></Card>}
    {state==='loading' && <Card className="p-7 text-center"><Loader2 size={30} className="text-teal animate-spin mx-auto mb-3"/><p className="text-ink-light">Finding the most relevant legal area…</p></Card>}
    {state==='unclear' && <Card className="p-6 mb-6"><div className="flex items-start gap-3"><AlertTriangle className="text-gold-600 shrink-0"/><div><h2 className="font-bold text-navy">I’m not completely sure what legal issue your situation involves.</h2><p className="text-sm text-ink-light mt-1">Which area is closest to what you’re dealing with?</p><div className="mt-4 flex flex-wrap gap-2">{legalDomains.filter(d=>d.id!=='family'&&d.id!=='money-banking'&&d.id!=='government'&&d.id!=='documents').map(d=><button key={d.id} onClick={()=>submit(d.id)} className="chip hover:chip-active">{d.label}</button>)}</div></div></div></Card>}

    <AnimatePresence>{state==='success' && response && <motion.div ref={ref} initial={{opacity:0,y:18}} animate={{opacity:1,y:0}} className="space-y-4">
      <Card className="p-5"><TrustBadge type="general">Your situation</TrustBadge><p className="mt-3 text-navy font-medium">{response.situationSummary}</p><div className="mt-3 flex flex-wrap gap-2">{response.possibleAreas.map(a=><span key={a} className="chip chip-active">{a}</span>)}</div></Card>
      <Card className="p-5"><h2 className="font-bold text-navy text-lg">What this may involve</h2><p className="mt-2 text-ink-light leading-relaxed">{response.whatThisMayInvolve}</p></Card>
      <Card className="p-5"><h2 className="font-bold text-navy text-lg">What you may want to check</h2><div className="mt-4 grid sm:grid-cols-2 gap-3">{response.whatToCheck.map(c=><div key={c.item} className="p-4 rounded-lg bg-navy/[0.03]"><p className="font-semibold text-navy text-sm">{c.item}</p><p className="mt-1 text-sm text-ink-light leading-relaxed">{c.explanation}</p></div>)}</div></Card>
      <Card className="p-5"><h2 className="font-bold text-navy text-lg">Possible next steps</h2><div className="mt-4 space-y-4">{response.possibleNextSteps.map(s=><div key={s.number} className="flex gap-4"><span className="text-teal font-bold w-8">{s.number}</span><div><p className="font-semibold text-navy text-sm">{s.title}</p><p className="text-sm text-ink-light mt-1 leading-relaxed">{s.explanation}</p></div></div>)}</div></Card>
      {response.officialSources.length>0 && <Card className="p-5"><h2 className="font-bold text-navy text-lg">Official sources</h2><div className="mt-3 space-y-2">{response.officialSources.map(s=><a key={s.url} href={s.url} target="_blank" rel="noreferrer" className="flex items-center justify-between p-3 rounded-lg bg-navy/[0.03] hover:bg-navy/[0.06]"><span><span className="block text-sm font-medium text-navy">{s.title}</span><span className="block text-xs text-ink-muted">{s.organization}</span></span><ExternalLink size={15} className="text-teal"/></a>)}</div></Card>}
      {response.relatedScenarioId && <Card hover className="p-5 bg-teal/[0.04]"><div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"><div><p className="section-label">Learn more</p><h2 className="mt-1 font-bold text-navy">{getScenarioById(response.relatedScenarioId)?.title}</h2><p className="text-sm text-ink-light mt-1">Explore the issue through an interactive fictional scenario.</p></div><Link to={`/learn/${response.relatedScenarioId}`} className="btn-secondary shrink-0">Start learning <ChevronRight size={16}/></Link></div></Card>}
      <Card className="p-5"><div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3"><div><h2 className="font-bold text-navy text-lg">Keep learning</h2><p className="text-sm text-ink-light mt-1">Look up unfamiliar terms in the Legal Dictionary.</p></div><Link to="/dictionary" className="btn-outline text-sm shrink-0"><BookOpen size={15}/> Open dictionary</Link></div></Card><Card className="p-5"><h2 className="font-bold text-navy text-lg">Questions to consider</h2><ul className="mt-3 space-y-2">{response.questionsToConsider.map(q=><li key={q} className="flex gap-2 text-sm text-ink-light"><HelpCircle size={15} className="text-teal shrink-0 mt-0.5"/>{q}</li>)}</ul></Card>
      <Disclaimer variant="full" />
      <div className="text-center"><button onClick={()=>{setInput('');setResponse(null);setState('idle');setSelectedDomain(null)}} className="btn-ghost">Describe another situation</button></div>
    </motion.div>}</AnimatePresence>
  </div></div>;
}
