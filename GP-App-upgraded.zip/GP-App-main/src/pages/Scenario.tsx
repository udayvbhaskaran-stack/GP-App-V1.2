import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, BookOpen, CheckCircle2, RotateCcw, LifeBuoy, ExternalLink } from 'lucide-react';
import { getScenarioById, scenarios } from '@/data/scenarios';
import { getSourceById } from '@/data/sources';
import { SceneView } from '@/components/SceneView';
import { ProgressBar } from '@/components/ProgressBar';
import { Card } from '@/components/Card';
import { Disclaimer } from '@/components/Disclaimer';
import { useProgress } from '@/hooks/useProgress';

export function Scenario() {
  const { scenarioId } = useParams<{ scenarioId: string }>();
  const navigate = useNavigate();
  const scenario = scenarioId ? getScenarioById(scenarioId) : undefined;
  const { completeScenario } = useProgress();
  const [current, setCurrent] = useState(0);
  const [discovered, setDiscovered] = useState<string[]>([]);
  const [complete, setComplete] = useState(false);

  useEffect(() => { setCurrent(0); setDiscovered([]); setComplete(false); }, [scenarioId]);
  if (!scenario) return <div className="py-20 text-center"><p className="text-ink-light">Scenario not found.</p><Link to="/learn" className="mt-4 inline-block btn-outline">Back to Learning</Link></div>;
  if (scenario.status === 'coming-soon') return <div className="py-20 text-center container-page"><p className="text-ink-light">This module is coming soon.</p><Link to="/learn" className="mt-4 inline-block btn-outline">Back to Learning</Link></div>;

  const scene = scenario.steps[current];
  const finish = () => { completeScenario(scenario.id, discovered); setComplete(true); };
  const reset = () => { setCurrent(0); setDiscovered([]); setComplete(false); };
  const addConcept = (id: string) => setDiscovered(prev => prev.includes(id) ? prev : [...prev, id]);

  if (complete) return (
    <div className="py-12"><div className="container-page max-w-3xl">
      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }}>
        <div className="text-center mb-8"><div className="w-16 h-16 rounded-full bg-teal/15 text-teal flex items-center justify-center mx-auto mb-4"><CheckCircle2 size={32}/></div><p className="section-label">Module completed</p><h1 className="mt-2 text-3xl font-bold text-navy">{scenario.title}</h1><p className="mt-2 text-ink-light">{discovered.length} concept{discovered.length !== 1 ? 's' : ''} explored</p></div>
        <Card className="p-6 mb-5"><h2 className="font-bold text-navy text-lg mb-4">What to remember</h2><div className="space-y-3">{scenario.takeaways.map((t,i)=><div key={t.id} className="flex gap-3"><span className="text-teal font-bold">{String(i+1).padStart(2,'0')}</span><p className="text-ink-light">{t.text}</p></div>)}</div></Card>
        <Card className="p-6 mb-5"><h2 className="font-bold text-navy text-lg mb-4">Explore the concepts</h2><div className="grid sm:grid-cols-2 gap-3">{scenario.concepts.map(c=><Link key={c.id} to={`/dictionary?term=${encodeURIComponent(c.term)}`} className="p-4 rounded-lg border border-navy/8 hover:border-teal/40 transition-colors"><p className="font-semibold text-navy">{c.term}</p><p className="text-sm text-ink-light mt-1">{c.simpleExplanation}</p></Link>)}</div></Card>
        {scenario.sourceIds.length > 0 && <Card className="p-6 mb-5"><h2 className="font-bold text-navy text-lg mb-3">Official sources</h2><div className="space-y-2">{scenario.sourceIds.map(getSourceById).filter(Boolean).map(s=><a key={s!.id} href={s!.url} target="_blank" rel="noreferrer" className="flex items-center justify-between p-3 rounded-lg bg-navy/[0.03] hover:bg-navy/[0.06]"><span><span className="block text-sm font-medium text-navy">{s!.title}</span><span className="block text-xs text-ink-muted">{s!.organization}</span></span><ExternalLink size={15} className="text-teal"/></a>)}</div></Card>}
        <Disclaimer variant="full" className="mb-6" />
        <div className="flex flex-col sm:flex-row gap-3"><button onClick={reset} className="btn-outline flex-1"><RotateCcw size={16}/> Restart scenario</button><Link to="/learn" className="btn-primary flex-1">Try another scenario <ArrowRight size={16}/></Link><Link to="/assistant" className="btn-secondary flex-1"><LifeBuoy size={16}/> Ask about a situation</Link></div>
      </motion.div>
    </div></div>
  );

  return <div className="py-8"><div className="container-page">
    <Link to="/learn" className="inline-flex items-center gap-1.5 text-sm text-ink-light hover:text-navy mb-6"><ArrowLeft size={16}/> Back to Learning</Link>
    <div className="mb-6"><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="section-label">{scenario.category} · {scenario.mechanic}</p><h1 className="mt-1 text-2xl sm:text-3xl font-bold text-navy">{scenario.title}</h1><p className="mt-2 text-ink-light max-w-2xl">{scenario.description}</p></div><span className="chip">{scenario.estimatedTime}</span></div><div className="mt-5"><ProgressBar value={current+1} max={scenario.steps.length} label={`Step ${current+1} of ${scenario.steps.length}`}/></div></div>
    <div className="flex flex-wrap gap-2 mb-5" aria-label="Concept progress">{scenario.concepts.map(c=><span key={c.id} className={`chip text-xs ${discovered.includes(c.id) ? 'chip-active' : ''}`}>{discovered.includes(c.id) && <CheckCircle2 size={12}/>} {c.term}</span>)}</div>
    <SceneView scene={scene} concepts={scenario.concepts} onConceptDiscovered={addConcept} discoveredConceptIds={discovered}/>
    <div className="mt-6 flex items-center justify-between gap-4"><button onClick={()=>setCurrent(v=>Math.max(0,v-1))} disabled={current===0} className={`btn-ghost ${current===0?'opacity-40 cursor-not-allowed':''}`}><ArrowLeft size={16}/> Previous</button><div className="flex gap-1.5">{scenario.steps.map((_,i)=><button key={i} aria-label={`Go to step ${i+1}`} onClick={()=>setCurrent(i)} className={`h-1.5 rounded-full ${i===current?'w-8 bg-teal':'w-2 bg-navy/15'}`}/>)}</div><button onClick={()=>current===scenario.steps.length-1 ? finish() : setCurrent(v=>v+1)} className="btn-primary">{current===scenario.steps.length-1?'Complete':'Continue'} <ArrowRight size={16}/></button></div>
    <div className="mt-12 pt-8 border-t border-navy/8"><h3 className="text-sm font-semibold text-ink-light mb-3">Continue exploring</h3><div className="flex flex-wrap gap-2">{scenarios.filter(s=>s.id!==scenario.id).slice(0,5).map(s=><Link key={s.id} to={`/learn/${s.id}`} className="chip hover:chip-active"><BookOpen size={14}/>{s.title}</Link>)}</div></div>
  </div></div>;
}
