import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, BookOpen, CheckCircle2, Clock, Filter } from 'lucide-react';
import { Card, SectionHeader } from '@/components/Card';
import { scenarios } from '@/data/scenarios';
import { useProgress } from '@/hooks/useProgress';

const filters = ['All','Police & Crime','Courts','Legal Help','Property & Land','Insurance','Work','Consumer','Housing','Digital','Other'];
const categoryMap: Record<string,string[]> = { Work:['Work & Employment'], Consumer:['Consumer Problems'], Digital:['Online & Digital Issues'], 'Legal Help':['Legal Help & Legal Aid'], Courts:['Courts','Courts & Legal Notices'], 'Police & Crime':['Police & Crime'], 'Property & Land':['Property & Land'], Insurance:['Insurance'], Housing:['Housing & Renting'] };

export function Learn() {
  const { completedScenarios } = useProgress();
  const [params] = useSearchParams();
  const initial = params.get('category');
  const initialLabel = initial === 'police-crime' ? 'Police & Crime' : initial === 'property-land' ? 'Property & Land' : initial === 'insurance' ? 'Insurance' : initial === 'employment' ? 'Work' : initial === 'consumer' ? 'Consumer' : initial === 'housing' ? 'Housing' : initial === 'courts' ? 'Courts' : initial === 'digital' ? 'Digital' : initial === 'legal-help' ? 'Legal Help' : 'All';
  const [active,setActive] = useState(initialLabel);
  const filtered = useMemo(()=>scenarios.filter(s=>active==='All' || (categoryMap[active]||[]).includes(s.category)),[active]);
  return <div className="py-12"><div className="container-page">
    <SectionHeader label="Interactive learning" title="Learn by doing" subtitle="Explore realistic situations, interact with the story and discover how legal concepts work in everyday life." className="mb-8" />
    <Card className="p-5 mb-8 bg-navy text-white border-0"><div className="flex flex-col md:flex-row md:items-center justify-between gap-5"><div><p className="text-white/60 text-xs uppercase tracking-wider font-semibold">Your learning journey</p><h2 className="text-xl font-bold mt-1">{completedScenarios.length} of {scenarios.length} scenarios completed</h2><p className="text-white/70 text-sm mt-1">Choose what matters to you. You do not need to complete everything.</p></div><div className="w-full md:w-64"><div className="h-2 rounded-full bg-white/15 overflow-hidden"><div className="h-full bg-teal" style={{width:`${Math.min(100,(completedScenarios.length/scenarios.length)*100)}%`}}/></div><p className="text-xs text-white/60 mt-2 text-right">{Math.round((completedScenarios.length/scenarios.length)*100)}% complete</p></div></div></Card>
    <div className="flex items-center gap-2 mb-4 text-sm text-ink-light"><Filter size={15}/> Filter scenarios</div>
    <div className="flex flex-wrap gap-2 mb-8">{filters.map(f=><button key={f} onClick={()=>setActive(f)} className={`chip ${active===f?'chip-active':''}`}>{f}</button>)}</div>
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
      {filtered.map((s,i)=>{const done=completedScenarios.includes(s.id);return <motion.div key={s.id} initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{delay:i*.04}}><Link to={`/learn/${s.id}`}><Card hover className="p-6 h-full"><div className="flex items-start justify-between gap-3"><span className="chip text-xs">{s.category}</span>{done&&<span className="chip chip-active"><CheckCircle2 size={12}/> Completed</span>}</div><h3 className="mt-4 text-lg font-bold text-navy">{s.title}</h3><p className="mt-2 text-sm text-ink-light leading-relaxed">{s.description}</p><div className="mt-4 flex flex-wrap gap-1.5">{s.conceptsCovered.map(c=><span key={c} className="chip text-xs">{c}</span>)}</div><div className="mt-5 pt-4 border-t border-navy/5 flex items-center justify-between"><span className="text-xs text-ink-muted flex items-center gap-1"><Clock size={12}/>{s.estimatedTime}</span><span className="text-xs text-teal font-medium">Interactive scenario</span></div><div className="mt-3 text-teal text-sm font-semibold inline-flex items-center gap-1">{done?'Review':'Start scenario'} <ArrowRight size={14}/></div></Card></Link></motion.div>})}
    </div>
    {filtered.length===0&&<Card className="p-8 text-center"><BookOpen className="mx-auto text-ink-muted mb-3"/><p className="text-ink-light">No scenarios match this filter yet.</p></Card>}
  </div></div>;
}
